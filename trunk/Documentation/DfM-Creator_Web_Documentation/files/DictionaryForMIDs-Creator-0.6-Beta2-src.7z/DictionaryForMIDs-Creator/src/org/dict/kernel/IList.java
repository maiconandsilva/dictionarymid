package org.dict.kernel;

/**
 * Insert the type's description here.
 * Creation date: (7/31/01 2:31:39 PM)
 * @author: Administrator
 */
public interface IList {
/**
 * Insert the method's description here.
 * Creation date: (7/31/01 2:32:01 PM)
 * @return Object
 * @param i int
 */
Object get(int i);
/**
 * Insert the method's description here.
 * Creation date: (7/31/01 2:32:24 PM)
 * @return int
 */
int size();
}
