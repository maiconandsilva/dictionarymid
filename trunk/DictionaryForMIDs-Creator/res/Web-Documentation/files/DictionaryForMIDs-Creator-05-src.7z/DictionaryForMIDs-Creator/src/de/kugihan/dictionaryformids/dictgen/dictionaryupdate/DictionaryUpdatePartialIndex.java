/*
DictionaryForMIDs - a free multi-language dictionary for mobile devices.
Copyright (C) 2005, 2006  Gert Nuber (
)

GPL applies - see file COPYING for copyright statement.
*/
/*
 * Note: this class is obsolete starting with DictionaryGeneration 3.5.0 because
 * with version 3.5.0 of DictionayGeneration the behaviour from DictionaryUpdatePartialIndex
 * is already included in class DictionaryUpdate. The class DictionaryUpdatePartialIndex
 * is only retained for compatibility reasons.
 */
package de.kugihan.dictionaryformids.dictgen.dictionaryupdate;


public class DictionaryUpdatePartialIndex extends DictionaryUpdate {
	
}
